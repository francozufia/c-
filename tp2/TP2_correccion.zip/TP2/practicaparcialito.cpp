#include <stdio.h>
int main(){
	
	int i;
	for(i=0;i<=3000;i=i+3){
		printf("los multiplos son:%d\n",i);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}

